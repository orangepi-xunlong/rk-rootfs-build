isp/isp.o: isp/isp.c \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/vi/include/sns_v4l2_uapi.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_bin.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_type.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_video.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_common.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_defines.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_awb.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_isp.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_inc.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_vi.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_3a.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_sns.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_debug.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_isp.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_awb_comm.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_af.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_af_comm.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_sns_ctrl.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_cif.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_errno.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_3a.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae_comm.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae_comm.h \
 /project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_isp.h \
 inc/cvi_isp_v4l2.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_vi.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_gdc.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_vb.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_sys.h \
 /project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_sys.h
/project/sophon/1688_v1.9_github/middleware/v2/modules/vi/include/sns_v4l2_uapi.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_bin.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_type.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_video.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_common.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_defines.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_awb.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_isp.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_inc.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_vi.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_3a.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_sns.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_debug.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_isp.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_awb_comm.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_af.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_af_comm.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_sns_ctrl.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_cif.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_errno.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_comm_3a.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae_comm.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_ae_comm.h:
/project/sophon/1688_v1.9_github/middleware/v2/modules/isp/include/cv186x/cvi_isp.h:
inc/cvi_isp_v4l2.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_vi.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_gdc.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_vb.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_sys.h:
/project/sophon/1688_v1.9_github/middleware/v2/include/cvi_comm_sys.h:
