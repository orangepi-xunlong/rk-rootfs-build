#ifndef MODULES_SYS_INCLUDE_BASE_H_
#define MODULES_SYS_INCLUDE_BASE_H_

#include <stdbool.h>
#include <stdint.h>
#include <sys/queue.h>
#include <semaphore.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>

#include <cvi_common.h>
#include <cvi_comm_sys.h>
#include "cvi_vi.h"
#include "cvi_vpss.h"
#include "cvi_debug.h"


#ifdef CVI_DEBUG
#define VPU_PROFILE
#endif

#define BIT(nr)      (UINT64_C(1) << (nr))

#define IS_VDEV_CLOSED(x) ((x) == VDEV_STATE_CLOSED)
#define IS_VDEV_OPEN(x) ((x) == VDEV_STATE_OPEN)
#define IS_VDEV_RUN(x) ((x) == VDEV_STATE_RUN)
#define IS_VDEV_STOP(x) ((x) == VDEV_STATE_STOP)

#if defined(ARCH_CV183X)
#define VPSS_GRP_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400))
#define VPSS_CHN_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400) ||		\
	 (fmt == PIXEL_FORMAT_HSV_888) || (fmt == PIXEL_FORMAT_HSV_888_PLANAR))
#define VO_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400))
#define GDC_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_400))
#elif defined(ARCH_CV182X) || defined(__CV181X__) || defined(__CV180X__) || defined(__CV186X__)
#define VPSS_GRP_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400) ||		\
	 (fmt == PIXEL_FORMAT_NV12) || (fmt == PIXEL_FORMAT_NV21) ||				\
	 (fmt == PIXEL_FORMAT_NV16) || (fmt == PIXEL_FORMAT_NV61) ||				\
	 (fmt == PIXEL_FORMAT_YUYV) || (fmt == PIXEL_FORMAT_UYVY) ||				\
	 (fmt == PIXEL_FORMAT_YVYU) || (fmt == PIXEL_FORMAT_VYUY) ||				\
	 (fmt == PIXEL_FORMAT_YUV_444))
#define VPSS_CHN_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400) ||		\
	 (fmt == PIXEL_FORMAT_HSV_888) || (fmt == PIXEL_FORMAT_HSV_888_PLANAR) ||		\
	 (fmt == PIXEL_FORMAT_NV12) || (fmt == PIXEL_FORMAT_NV21) ||				\
	 (fmt == PIXEL_FORMAT_NV16) || (fmt == PIXEL_FORMAT_NV61) ||				\
	 (fmt == PIXEL_FORMAT_YUYV) || (fmt == PIXEL_FORMAT_UYVY) ||				\
	 (fmt == PIXEL_FORMAT_YVYU) || (fmt == PIXEL_FORMAT_VYUY) ||				\
	 (fmt == PIXEL_FORMAT_YUV_444) ||											\
	 (fmt == PIXEL_FORMAT_FP32_C3_PLANAR) || (fmt == PIXEL_FORMAT_FP16_C3_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_BF16_C3_PLANAR) || (fmt == PIXEL_FORMAT_INT8_C3_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_UINT8_C3_PLANAR))
#define VO_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_RGB_888) || (fmt == PIXEL_FORMAT_BGR_888) ||			\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_PLANAR_422) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_400) ||		\
	 (fmt == PIXEL_FORMAT_NV12) || (fmt == PIXEL_FORMAT_NV21) ||				\
	 (fmt == PIXEL_FORMAT_NV16) || (fmt == PIXEL_FORMAT_NV61) ||				\
	 (fmt == PIXEL_FORMAT_YUYV) || (fmt == PIXEL_FORMAT_UYVY) ||				\
	 (fmt == PIXEL_FORMAT_YVYU) || (fmt == PIXEL_FORMAT_VYUY))

#define GDC_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_NV12) || (fmt == PIXEL_FORMAT_NV21) ||				\
	 (fmt == PIXEL_FORMAT_YUV_400))
#define DWA_SUPPORT_FMT(fmt) \
	((fmt == PIXEL_FORMAT_RGB_888_PLANAR) || (fmt == PIXEL_FORMAT_BGR_888_PLANAR) ||	\
	 (fmt == PIXEL_FORMAT_YUV_PLANAR_444) || (fmt == PIXEL_FORMAT_YUV_PLANAR_420) || (fmt == PIXEL_FORMAT_YUV_400))

#else
#error "ARCH not defined"
#endif


#define BASE_DEV_NAME "/dev/soph-base"
#define SYS_DEV_NAME  "/dev/soph-sys"
#define VI_DEV_NAME   "/dev/soph-vi"
#define VPSS_DEV_NAME "/dev/soph-vpss"
#define LDC_DEV_NAME  "/dev/soph-ldc"
#define VO_DEV_NAME   "/dev/soph-vo"
#define RGN_DEV_NAME  "/dev/soph-rgn"
#define DPU_DEV_NAME  "/dev/soph-dpu"
#define HDMI_DEV_NAME  "/dev/soph-hdmi"
#define STITCH_DEV_NAME "/dev/soph-stitch"

#define ISP_CHECK_PIPE(pipe)                                                                                           \
	do {                                                                                                           \
		if (((pipe) < 0) || ((pipe) >= VI_MAX_PIPE_NUM)) {                                                     \
			return -ENODEV;                                                                                \
		}                                                                                                      \
	} while (0)

#define MOD_CHECK_NULL_PTR(id, ptr)                                                                                   \
	do {                                                                                                           \
		if (!(ptr)) {                                                                                          \
			CVI_TRACE_ID(CVI_DBG_ERR, id, #ptr " NULL pointer\n");                                         \
			return CVI_DEF_ERR(id, EN_ERR_LEVEL_ERROR, EN_ERR_NULL_PTR);                                   \
		}                                                                                                      \
	} while (0)

#define Mo_Table_Size 256
#define DEFAULT_MESH_PADDR	0x80000000

enum vdev_type {
	VDEV_TYPE_ISP = 0,
	VDEV_TYPE_VPSS,
	VDEV_TYPE_DISP,
	VDEV_TYPE_LDC,
	VDEV_TYPE_RGN,
	// VDEV_TYPE_DWA,
	VDEV_TYPE_DPU,
	VDEV_TYPE_HDMI,
	VDEV_TYPE_MAX,
};

enum vdev_state {
	VDEV_STATE_CLOSED = 0,
	VDEV_STATE_OPEN,
	VDEV_STATE_RUN,
	VDEV_STATE_STOP,
	VDEV_STATE_MAX,
};

// start point is included.
// end point is excluded.
struct crop_size {
	CVI_U16  start_x;
	CVI_U16  start_y;
	CVI_U16  end_x;
	CVI_U16  end_y;
};

enum GDC_USAGE {
	GDC_USAGE_ROTATION,
	GDC_USAGE_FISHEYE,
	GDC_USAGE_LDC,
	GDC_USAGE_MAX
};

struct cvi_gdc_mesh {
	CVI_U64 paddr;
	CVI_VOID *vaddr;
	CVI_U32 meshSize;
	pthread_mutex_t lock;
};

/* dis_info: pass dis crop infor to VI.
 *
 * sensor_num: define which sensor.
 * frm_num: define the crop info is for which frame.
 * crop_size: dis crop size info.
 */
// ++++++++ If you want to change these interfaces, please contact the isp team. ++++++++
struct dis_info {
	CVI_U8  sensor_num;
	CVI_U32 frm_num;
	struct crop_size dis_i;
};
// -------- If you want to change these interfaces, please contact the isp team. --------

// ++++++++ If you want to change these interfaces, please contact the isp team. ++++++++
struct mlv_info {
	CVI_U8  sensor_num;
	CVI_U32 frm_num;
	CVI_U8  mlv;
	CVI_U8  mtable[Mo_Table_Size];
};
// -------- If you want to change these interfaces, please contact the isp team. --------
#if 0
// ++++++++ If you want to change these interfaces, please contact the isp team. ++++++++
struct vdev {
	char name[64];
	CVI_S32 fd;
	CVI_U8 numOfBuffers;
	CVI_U8 availIndex;
	CVI_U8 numOfPlanes;
	enum vdev_state state;
	bool is_online;
};
#endif
// -------- If you want to change these interfaces, please contact the isp team. --------

// ++++++++ If you want to change these interfaces, please contact the isp team. ++++++++
struct vdev *get_dev_info(CVI_U8 type, CVI_U8 dev_id);
// -------- If you want to change these interfaces, please contact the isp team. --------
int open_device(const char *dev_name, CVI_S32 *fd);
CVI_S32 close_device(CVI_S32 *fd);

CVI_S32 base_dev_open(CVI_VOID);
CVI_S32 base_dev_close(CVI_VOID);
CVI_S32 get_base_fd(CVI_VOID);

long get_diff_in_us(struct timespec t1, struct timespec t2);

// ++++++++ If you want to change these interfaces, please contact the isp team. ++++++++
CVI_VOID CVI_VI_SET_DIS_INFO(struct dis_info dis_i);
CVI_S32 CVI_VI_SetBypassFrm(CVI_U32 snr_num, CVI_U8 bypass_num);
CVI_VOID CVI_VI_SetMotionLV(struct mlv_info mlevel_i);
// -------- If you want to change these interfaces, please contact the isp team. --------

void *base_get_shm(void);
void base_release_shm(void);

CVI_S32 CVI_VPSS_Suspend(void);
CVI_S32 CVI_VPSS_Resume(void);
CVI_S32 CVI_GDC_Suspend(void);
CVI_S32 CVI_GDC_Resume(void);
CVI_S32 CVI_VO_Suspend(void);
CVI_S32 CVI_VO_Resume(void);

CVI_S32 get_sys_fd(CVI_VOID);
CVI_S32 sys_dev_open(CVI_VOID);
CVI_S32 sys_dev_close(CVI_VOID);
#endif // MODULES_SYS_INCLUDE_BASE_H_
