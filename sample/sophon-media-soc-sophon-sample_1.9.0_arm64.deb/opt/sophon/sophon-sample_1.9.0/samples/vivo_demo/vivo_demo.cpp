#include "vivo_demo.hpp"
#include <sys/time.h>
#include <csignal>
#include <iostream>
#include <thread>
#include <queue>
#include <mutex>
#include <memory>
#include <fcntl.h>
#include <sys/mman.h>
#include <poll.h>

extern "C" {
#include "libavformat/avformat.h"
#include "libavutil/imgutils.h"
#include "libswscale/swscale.h"
#include "libavformat/avio.h"
#include "libavdevice/avdevice.h"
#include "libavutil/pixdesc.h"
#include "libavutil/hwcontext_drm.h"

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "bmcv_api_ext.h"
#include "bmlib_runtime.h"
}

#define MAX_THREAD_NUM  12
#define PARAM_SET_INDEP 3
#define DRM_DEVICE      "/dev/dri/card0"
#define DOUBLE_BUFFER   2

static int current_fb = 0;
static volatile int flip_pending = 0;

int quit_flag = 0;
int loopflag = 0;
unsigned int count_dec[MAX_THREAD_NUM];
unsigned int count_enc[MAX_THREAD_NUM];
float fps_dec[MAX_THREAD_NUM];
float fps_enc[MAX_THREAD_NUM];
int g_stop_flag[MAX_THREAD_NUM] = {0};
std::thread dec_thread[MAX_THREAD_NUM];
std::thread enc_thread[MAX_THREAD_NUM];
bm_handle_t g_bmHandle        = {0};
std::queue<std::shared_ptr<AVFrame>> g_image_enc_queue[MAX_THREAD_NUM];
std::mutex g_enc_queue_lock[MAX_THREAD_NUM];
std::mutex g_thread_num_lock;
VideoDec_FFMPEG g_reader[MAX_THREAD_NUM];

struct DRMContext{
    int fd;
    uint32_t conn_id;
    uint32_t crtc_id;
    uint32_t width;
    uint32_t height;
    drmModeModeInfo mode;
} drm;

typedef struct {
    uint32_t fb_id;
    uint32_t handle;
    uint32_t pitch;
    size_t size;
    void *map;
} DrmBuffer;
static DrmBuffer bufs[2];

static void usage(char *program_name) {
    av_log(NULL, AV_LOG_ERROR, "Usage: \n\t%s devnum <input dev> <output file> <wdr_on> ... encoder framerate bitrate(kbps) use_isp v4l2_buf_num framenum loopflag\n", program_name);

    av_log(NULL, AV_LOG_ERROR, "\tencoder: H264 or H265, H264 is default.\n");
    av_log(NULL, AV_LOG_ERROR, "\tdevnum: must be set to [1,12].\n");
    av_log(NULL, AV_LOG_ERROR, "\tuse_isp:  use isp or not\n");
    av_log(NULL, AV_LOG_ERROR, "\tloopflag: If it is 0, it will encode and decode based on the number of frames; if it is 1, it will continuously encode and decode without generating valid videoes.\n");
    av_log(NULL, AV_LOG_ERROR, "\twdr_on: open the wdr mode or not\n");
    av_log(NULL, AV_LOG_ERROR, "Examples:\n");
    av_log(NULL, AV_LOG_ERROR, "\t%s 6 /dev/video0 /mnt/video0.264 0 /dev/video1 /mnt/video1.264 0 /dev/video2 /mnt/video2.264 0 /dev/video3 /mnt/video3.264 0 /dev/video4 /mnt/video4.264 0 /dev/video5 /mnt/video5.264 0 H264 30 3000 1 10 901 0\n", program_name);
}

void handler(int sig) {
    quit_flag = 1;
    av_log(NULL, AV_LOG_INFO, "program will exited \n");
}

int video_decoder_pthread(const char* input_file, int sophon_idx, int framenum, int v4l2_buf_num,
                         int use_isp, int wdr_on, int outputCount, int index);

static void handle_page_flip(int fd, unsigned int frame,
                            unsigned int sec, unsigned int usec, void *data) {
    flip_pending = 0;
}

static int add_fb(std::shared_ptr<AVFrame> frame)
{
    int ret;
    int back_fb = 1 - current_fb;

    uint8_t *dst = (uint8_t *)bufs[back_fb].map;
    uint8_t *src = frame->data[0];
    int dst_pitch = bufs[back_fb].pitch;
    int src_pitch = frame->linesize[0];
    int height = frame->height;
    int width = frame->width * 3 / 2;

    /* Y PART*/
    const int src_y_stride = frame->linesize[0];
    const int dst_y_stride = drm.width;
    for (int y = 0; y < drm.height; y++) {
        const uint8_t *src = frame->data[0] + y * src_y_stride;
        uint8_t *dst = (uint8_t *)bufs[back_fb].map + y * dst_y_stride;
        memcpy(dst, src, dst_y_stride);
    }

    /*UV PART*/
    const int src_uv_stride = frame->linesize[1];
    const int dst_uv_stride = drm.width;
    const int uv_offset = drm.width * drm.height;
    for (int y = 0; y < drm.height / 2; y++) {
        const uint8_t *src = frame->data[1] + y * src_uv_stride;
        uint8_t *dst = (uint8_t *)bufs[back_fb].map + uv_offset + y * dst_uv_stride;
        memcpy(dst, src, dst_uv_stride);
    }

    flip_pending = 1;
    drmModePageFlip(drm.fd, drm.crtc_id, bufs[back_fb].fb_id,
                    DRM_MODE_PAGE_FLIP_EVENT, NULL);

    struct pollfd pfd = { .fd = drm.fd, .events = POLLIN };
    while (flip_pending) {
        poll(&pfd, 1, -1);
        drmEventContext evctx = {
            .version = DRM_EVENT_CONTEXT_VERSION,
            .page_flip_handler = handle_page_flip
        };
        drmHandleEvent(drm.fd, &evctx);
    }
    current_fb = back_fb;

	return 0;
}

int init_drm(){
    drmModeRes *res;
    drmModeConnector *conn;
    drmModeEncoder *enc;

    drm.fd = open(DRM_DEVICE, O_RDWR | O_CLOEXEC);
    if (drm.fd < 0){
        printf("can't open drm device\n ");
        return -1;
    }

    res = drmModeGetResources(drm.fd);
    if (!res)
        return -1;

    for (int i = 0; i < res->count_connectors; i++) {
        conn = drmModeGetConnector(drm.fd, res->connectors[i]);
        if (conn->connection == DRM_MODE_CONNECTED) {
            drm.conn_id = conn->connector_id;
            break;
        }
    }

    drm.crtc_id = res->crtcs[1];
	drm.width = conn->modes[0].hdisplay;
	drm.height = conn->modes[0].vdisplay;
    memcpy(&drm.mode, &conn->modes[0], sizeof(drmModeModeInfo));

    printf("current crtc_id:%d, conn_id:%d, %dx%d\n", drm.crtc_id,  drm.conn_id, drm.width, drm.height);

    for (int i = 0; i < DOUBLE_BUFFER; i++) {
        struct drm_mode_create_dumb create_dumb;

		memset(&create_dumb, 0, sizeof(create_dumb));
		create_dumb.bpp = 8; // NV21
		create_dumb.width =  drm.width;
		create_dumb.height =  drm.height * 3 / 2; // NV21
        if (drmIoctl(drm.fd, DRM_IOCTL_MODE_CREATE_DUMB, &create_dumb)) {
            printf("drm create dumb failed, %s\n", strerror(errno));
            return -1;
        }

        bufs[i].handle = create_dumb.handle;
        bufs[i].pitch = create_dumb.pitch;
        bufs[i].size = create_dumb.size;

        struct drm_mode_map_dumb map_dumb;
        memset(&map_dumb, 0, sizeof(map_dumb));
        map_dumb.handle = create_dumb.handle;
        if (drmIoctl(drm.fd, DRM_IOCTL_MODE_MAP_DUMB, &map_dumb)) {
             printf("drm mmap failed, %s\n", strerror(errno));
            return -1;
        }


        bufs[i].map = mmap(0, create_dumb.size, PROT_READ | PROT_WRITE,
                         MAP_SHARED, drm.fd, map_dumb.offset);
        if (bufs[i].map == MAP_FAILED) {
            printf("mmap failed, %s\n", strerror(errno));
            return -1;
        }

        printf("mmap: %d, %p,  size:%d\n", i, bufs[i].map, bufs[i].size);

        /* 创建framebuffer */
        unsigned int handles[4];
        unsigned int pitches[4];
        unsigned int offsets[4];
        unsigned int length[3];

		handles[0] = create_dumb.handle;
		pitches[0] = create_dumb.pitch;
        offsets[0] = 0;

		handles[1] = create_dumb.handle;
        pitches[1] = pitches[0];
		offsets[1] = pitches[0] * drm.height;

        if (drmModeAddFB2(drm.fd,  drm.width,  drm.height, DRM_FORMAT_NV21,
                            handles, pitches, offsets, &bufs[i].fb_id, 0)) {
            printf("drmModeAddFB2 failed, %s\n", strerror(errno));
            return -1;
        }

    }

    drmModeSetCrtc(drm.fd, drm.crtc_id, bufs[0].fb_id,
		0, 0, &drm.conn_id, 1, &drm.mode);

    drmModeFreeConnector(conn);
    drmModeFreeResources(res);

    return 0;
}

int main(int argc, char **argv) {
    avdevice_register_all();
    int ret = 0;
    int framerate = 30;
    int bitrate = 3000;
    int sophon_idx = 0;
    int framenum = 400;
    int v4l2_buf_num = 8;
    int use_isp = 1;
    int enccodec_id = AV_CODEC_ID_H264;
    std::thread threads[MAX_THREAD_NUM];
    DRMContext drm = {0};
    signal(SIGINT,handler);
    signal(SIGTERM,handler);

    if (argc < 3) {
        usage(argv[0]);
        return -1;
    }
    int outputCount = atoi(argv[1]);
    if (outputCount <= 0 || outputCount >= 13) {
        av_log(NULL, AV_LOG_WARNING, "devnum must be set to [1,12]\n");
        return 1;
    }
    std::string outputFiles[outputCount];
    std::string inputFiles[outputCount];
    int wdr_off_on[outputCount];

    for (int i = 0; i < outputCount; i++) {
        inputFiles[i] = argv[i*PARAM_SET_INDEP + 2];
        outputFiles[i] = argv[i*PARAM_SET_INDEP  + 3];
        wdr_off_on[i] = atoi(argv[i*PARAM_SET_INDEP + 4]);
    }

    if (argc > outputCount*PARAM_SET_INDEP + 2) {
        if (strstr(argv[outputCount*PARAM_SET_INDEP + 2],"H265") != NULL) {
           enccodec_id = AV_CODEC_ID_H265;
        }
    }
    if (argc > outputCount*PARAM_SET_INDEP + 3) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 3]);
        if (temp >10 && temp <= 60) {
             framerate = temp;
        } else {
            av_log(NULL, AV_LOG_WARNING, "frameteate must be set to (10,60]\n");
            return 1;
        }
        av_log(NULL, AV_LOG_INFO, "framerate = %d \n",framerate);
    }
    if (argc > outputCount*PARAM_SET_INDEP + 4) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 4]);
        if (temp >500 && temp < 10000) {
             bitrate = temp*1000;
        } else {
            av_log(NULL, AV_LOG_WARNING, "bitrate must be set to (500,10000)\n");
            return 1;
        }
        av_log(NULL, AV_LOG_INFO, "bitrate = %d \n", bitrate);
    }
    if (argc > outputCount*PARAM_SET_INDEP + 5) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 5]);
        if (temp >= 0 && temp <= 1) {
            use_isp = temp;
        } else {
            av_log(NULL, AV_LOG_WARNING, "use_isp must be set to [0,1]\n");
            return 1;
        }
        av_log(NULL, AV_LOG_INFO, "use_isp = %d \n", use_isp);
    }
    if (argc > outputCount*PARAM_SET_INDEP + 6) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 6]);
        if (temp > 0 && temp < 32) {
            v4l2_buf_num = temp;
        } else {
            av_log(NULL, AV_LOG_WARNING, "buf num must be set to (0,32)\n");
            return 1;
        }
        av_log(NULL, AV_LOG_INFO, "v4l2_buf_num = %d \n", v4l2_buf_num);
    }
    if (argc > outputCount*PARAM_SET_INDEP + 7) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 7]);
        if (temp >= 1) {
            framenum = temp;
        } else {
            av_log(NULL, AV_LOG_WARNING, "frame num must >= 1\n");
            return 1;
        }
        av_log(NULL, AV_LOG_INFO, "framenum = %d \n", framenum);
    }
    if (argc > outputCount*PARAM_SET_INDEP + 8) {
        int temp = atoi(argv[outputCount*PARAM_SET_INDEP + 8]);
        if (temp == 1) {
            loopflag = temp;
            av_log(NULL, AV_LOG_WARNING, "endless loop is opening , video isn't saved ");
        }
        av_log(NULL, AV_LOG_INFO, "loopflag = %d \n", loopflag);
    }

    ret = bm_dev_request(&g_bmHandle, 0);
    if (ret != BM_SUCCESS){
        av_log(NULL, AV_LOG_DEBUG, "bm_dev_request failed !\n");
        return -1;
    }

    init_drm();

    for (int i = 0; i < outputCount; i++) {
        dec_thread[i] = std::thread(video_decoder_pthread, inputFiles[i].c_str(), sophon_idx, framenum, v4l2_buf_num,
                                    use_isp, wdr_off_on[i], outputCount, i);
    }

    for (int i = 0; i < outputCount; i++) {
        if (dec_thread[i].joinable()) {
            dec_thread[i].join();
        }
    }

    if (g_bmHandle) {
        bm_dev_free(g_bmHandle);
    }

    for (int i = 0; i < 2; i++) {
        munmap(bufs[i].map, bufs[i].size);
        struct drm_mode_destroy_dumb destroy_dumb = { .handle = bufs[i].handle };
        drmIoctl(drm.fd, DRM_IOCTL_MODE_DESTROY_DUMB, &destroy_dumb);
        drmModeRmFB(drm.fd, bufs[i].fb_id);
    }
    close(drm.fd);

    return 0;
}

int video_decoder_pthread(const char* input_file, int sophon_idx, int framenum, int v4l2_buf_num,
                        int use_isp, int wdr_on, int outputCount, int index) {
    VideoDec_FFMPEG* reader = &g_reader[index];
    pthread_t tid = pthread_self();
    std::shared_ptr<AVFrame> frame;
    auto startTime = std::chrono::steady_clock::now();
    auto currentTime = std::chrono::steady_clock::now();
    std::chrono::milliseconds::rep elapsedTime;
    int ret = 0, cur = 0;
    ret = reader->openDec(input_file, 9, sophon_idx, v4l2_buf_num, use_isp, wdr_on, outputCount);
    if (ret < 0) {
        av_log(NULL, AV_LOG_INFO, "#################open input media failed  ##########\n");
        return -1;
    }

    while (!quit_flag) {
        frame = std::shared_ptr<AVFrame>(av_frame_alloc(), [](AVFrame* p){av_frame_unref(p); av_frame_free(&p);});
        ret = reader->grabFrame(frame.get());
        if (ret < 0) {
            break;
        }

        if (add_fb(frame)) {
            printf("add_fb error");
            continue;;
        }

    }

    frame = std::shared_ptr<AVFrame>(av_frame_alloc(), [](AVFrame* p){av_frame_unref(p); av_frame_free(&p);});
    ret = reader->flushFrame(frame.get());

    av_log(NULL, AV_LOG_INFO, "video decode finish!\n");
    return 0;
}

