#ifndef __RESOURCE_cheese_H__
#define __RESOURCE_cheese_H__

#include <gio/gio.h>

extern GResource *cheese_get_resource (void);
#endif
